(() => {
  try {
    // top-level 치지직 탭에서는 스킵 — iframe embed만
    window.parent.location.hostname;
    return;
  } catch {}

  if (!location.search.includes('map-dyoa-preview=1')) return;

  const STYLE_ID = 'map-dyoa-preview-style';
  const CSS = `
    html, body, #root {
      overflow: hidden !important;
      width: 100% !important;
      height: 100% !important;
      margin: 0 !important;
      background: #000 !important;
    }
    #layout-header,
    header,
    [class*="header_container"],
    [class*="top_banner"],
    #lnb,
    [class*="navigator_"],
    [class*="lnb_"],
    aside[class*="aside"],
    [class*="sidebar"],
    aside[class*="live_chatting"],
    [class*="live_chatting_"],
    [class*="live_information_heading"],
    [class*="live_information_title"],
    [class*="live_information_name"],
    [class*="live_information_detail"],
    [class*="live_information_content"],
    [class*="live_information_badge"],
    [class*="tag_container"],
    [class*="video_information"],
    [class*="channel_info"] {
      display: none !important;
    }
    #layout-body,
    #layout-body > *,
    [class^="live_wrapper__"],
    [class*="live_container"],
    [class*="live_content"],
    [class^="live_information_player__"],
    [class^="live_information_video_container__"],
    #live_player_layout,
    #player_layout,
    [class*="webplayer"],
    [class*="player_container"] {
      position: fixed !important;
      inset: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      max-width: none !important;
      max-height: none !important;
      margin: 0 !important;
      padding: 0 !important;
      border: none !important;
      background: #000 !important;
      transform: none !important;
      z-index: 2147483000 !important;
    }
    video.webplayer-internal-video,
    video {
      width: 100% !important;
      height: 100% !important;
      object-fit: contain !important;
      background: #000 !important;
    }
    [class*="pzp-pc-ui-toast"],
    [class*="toast"] {
      opacity: 0 !important;
      pointer-events: none !important;
    }
  `;

  const ensure = () => {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = CSS;
    (document.documentElement || document.head || document.body)?.appendChild(style);
  };

  ensure();
  const obs = new MutationObserver(ensure);
  obs.observe(document.documentElement, { childList: true });
})();
